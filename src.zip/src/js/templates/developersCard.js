export const developers = [
  {
    name: 'Julia Rudenko',
    img: 'https://avatars.githubusercontent.com/u/105347404?v=4',
    position: 'Team Leader',
    github: 'https://github.com/jrudenko',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
    

  },

  {
    name: 'Yana Vinnichuk',
    img: 'https://avatars.githubusercontent.com/u/97412592?v=4',
    position: 'Scrum Master',
     github: 'https://github.com/Tisotti',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',

  },

  {
    name: 'Anrii Sereda',
    img: 'https://avatars.githubusercontent.com/u/102906498?v=4',
    position: 'Developer',
     github: 'https://github.com/SeredaAndrey',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
 
  },

    {
    name: 'Dima Krupenko',
    img: 'https://avatars.githubusercontent.com/u/105938881?v=4',
      position: 'Developer',
     github: 'https://github.com/DimaKrupenko',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
  
  },

  {
    name: 'Dmytro Savych',
    img: 'https://avatars.githubusercontent.com/u/92891294?v=4',
    position: 'Developer',
     github: 'https://github.com/sava12012',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
   
  },

   {
    name: 'Oksana Gluschenko',
    img: 'https://avatars.githubusercontent.com/u/105308639?v=4',
     position: 'Developer',
     github: 'https://github.com/oksanaglu',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
 
  },

   {
    name: 'Dmytro Kylymnyk',
    img: 'https://avatars.githubusercontent.com/u/104536061?v=4',
     position: 'Developer',
     github: 'https://github.com/DimaKIL',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
   
  },
  

  {
    name: 'Marina Mirzakhanova',
    img: 'https://avatars.githubusercontent.com/u/98583249?v=4',
    position: 'Developer',
     github: 'https://github.com/MsMirzakhanova',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
  
  },

 {
    name: 'Oleksandr Ronskyi',
    img: 'https://avatars.githubusercontent.com/u/105918973?v=4',
   position: 'Developer',
     github: 'https://github.com/Ronskyi-O',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',

  },
              
  {
    name: 'Sviatoslav',
    img: 'https://avatars.githubusercontent.com/u/106432553?v=4',
    position: 'Developer',
     github: 'https://github.com/Sviatoslav43',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',

  },

  {
    name: 'Alex',
    img: 'https://avatars.githubusercontent.com/u/105703672?v=4',
    position: 'Developer',
     github: 'https://github.com/AlexSol1702',
    linkedin: 'https://www.linkedin.com/',
    instagram: 'https://www.instagram.com/',
    facebook: 'https://www.facebook.com/',
 
  },
                           
 
                                  
];